Uchoa, E., Pecin, D., Pessoa, A., Poggi, M., Subramanian, A. and Vidal, T. (2014). New Benchmark Instances
for the Capacitated Vehicle Routing Problem.
------------------------------------------------------------------------------------------
Remarks:
 - <node>: attribute type=0 for the depot and 1 for customer nodes
 - <decimals>: the authors suggest rounding the distances to the closest integer value, following the TSPLIB standard.
 
  